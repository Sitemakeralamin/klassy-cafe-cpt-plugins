<?php

/*
Plugin Name: Klassy Cafe Custom Post
Plugin URI: https://alamin.com/
Description: Klassy Cafe Custom Plugin Use for Custom Post.
Version: 1.2
Author: mdalamin
Author URI: https://mdalamin.com
Text Domain: klassy_cafe
*/


//---------------
// Custom Post Creator
//---------------


function custom_post(){
	
	
//---------------
// Custom Post Slider
//---------------

	
	register_post_type('slider',array(
	
		'labels'=>array(
		
			'name'=>__('sliders','klassy_cafe '),
			'singular_name'=>__('slider','klassy_cafe '),
			'add_new_item'=>__('Add New Slider','klassy_cafe'),
			'search_items'=>__('Search Slider','klassy_cafe'),
			'edit_item'=>__('Edit Slider','klassy_cafe'),
		
		),
		
		'public'=>true,
		'supports'=>array('title','editor','thumbnail'),
	
	));
	
//---------------
// Custom Post food Menu
//---------------

	
		register_post_type('food_menu',array(
		
		'labels'=>array(
		
			'name'=>__('Menu Food','klassy_cafe '),
			'singular_name'=>__('Menu','klassy_cafe '),
			'add_new_item'=>__('Add New Menu Item','klassy_cafe'),
			'search_items'=>__('Search Menu Item','klassy_cafe'),
			'edit_item'=>__('Edit Menu Item','klassy_cafe'),
		
		),
	
		'public'=>true,
		'supports'=>array('title','editor','thumbnail'),
		
	));
	
//---------------
// Custom Post for chefs
//---------------

register_post_type('chefs',array(
		
		'labels'=>array(
		
			'name'=>__(' Our Chefs','klassy_cafe '),
			'singular_name'=>__('Chefs','klassy_cafe '),
			'add_new_item'=>__('Add New Chefs','klassy_cafe'),
			'search_items'=>__('Search Chefs Item','klassy_cafe'),
			'edit_item'=>__('Edit Chefs Item','klassy_cafe'),
		
		),
	
		'public'=>true,
		'supports'=>array('title','editor','thumbnail','page-attributes'),
		
	));
	
	


}

	add_action('init','custom_post');

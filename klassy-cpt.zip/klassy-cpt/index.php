<?php\
	
	//Silence is Golden